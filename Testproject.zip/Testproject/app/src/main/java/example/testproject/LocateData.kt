package example.testproject

data class LocateData(
    val id: Int,
    val latitude: Double,
    val longitude: Double,
    val address: String,
    val weather: String
)