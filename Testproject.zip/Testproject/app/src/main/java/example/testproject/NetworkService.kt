package example.testproject

import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Retrofit



object NetworkService {
    private var mInstance: NetworkService? = null

    private val BASE_URL = "api.openweathermap.org/data/2.5/weather"




    val instance: NetworkService
        get() {
            val mRetrofit: Retrofit
            if (mInstance == null) {
                mInstance = NetworkService
                mRetrofit = Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }
            return mInstance!!
        }
}