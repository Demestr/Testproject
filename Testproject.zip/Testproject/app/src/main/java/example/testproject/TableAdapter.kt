package example.testproject


import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.view.LayoutInflater


class TableAdapter : RecyclerView.Adapter<TableAdapter.TableViewHolder>() {

    private val locates = ArrayList<LocateData>()

    fun setItems(tweets: Collection<LocateData>) {
        locates.addAll(tweets)
        notifyDataSetChanged()
    }

    fun clearItems() {
        locates.clear()
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return locates.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TableViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.locate_item, parent, false)
        return TableViewHolder(view)
    }

    override fun onBindViewHolder(holder: TableViewHolder, position: Int) {
        holder.txtLatitude.text = locates[position].latitude.toString()
        holder.txtLongitude.text = locates[position].longitude.toString()
        holder.txtAddress.text = locates[position].address
        holder.txtWeather.text = locates[position].weather
    }


    class TableViewHolder(item: View) : RecyclerView.ViewHolder(item){
        val txtLatitude = item.findViewById<TextView>(R.id.txtLat)
        val txtLongitude = item.findViewById<TextView>(R.id.txtLong)
        val txtAddress = item.findViewById<TextView>(R.id.txtAddress)
        val txtWeather = item.findViewById<TextView>(R.id.txtWeather)
    }
}