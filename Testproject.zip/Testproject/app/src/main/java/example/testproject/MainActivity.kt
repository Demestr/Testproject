package example.testproject

import android.Manifest
import android.arch.lifecycle.ViewModelProviders
import android.content.pm.PackageManager
import android.databinding.DataBindingUtil
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.material.snackbar.Snackbar
import example.testproject.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    val locatePermission = arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: LocateViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        binding.viewPager.adapter = ViewPagerAdapter(supportFragmentManager)
        binding.tabLayout.setupWithViewPager(binding.viewPager)
        viewModel = ViewModelProviders.of(this, LocateViewModelFactory(application)).get(LocateViewModel::class.java)

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ){
            viewModel.getCurrentLocate()
        } else {
            ActivityCompat.requestPermissions(this, locatePermission, 0)
        }

    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ){
            viewModel.getCurrentLocate()
        } else {
            Snackbar.make(binding.tabLayout, "Нет разрешения!", Snackbar.LENGTH_LONG).show()
        }
    }
}
