package example.testproject

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel
import android.content.Context
import android.location.*
import android.os.Bundle
import android.util.Log
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*


class LocateViewModel(context: Context) : ViewModel(){

    private var locationManager: LocationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val locationListener = MyLocationListener()
    val resources = context.resources
    private var geocoder = Geocoder(context, Locale.getDefault())
    private val _latitude = MutableLiveData<Double>()
    private val _longitude = MutableLiveData<Double>()
    private val _address = MutableLiveData<String>()
    private val _weather = MutableLiveData<String>()

    val latitude: LiveData<Double>
    get() = _latitude

    val longitude: LiveData<Double>
        get() = _longitude

    val address: LiveData<String>
        get() = _address

    val weather: LiveData<String>
        get() = _weather


    private fun reverseGeo(lat: Double, lng: Double){
        val addresses = geocoder.getFromLocation(lat, lng, 1)
        if(addresses[0] != null) {
            _address.value = resources.getString(
                R.string.address,
                addresses[0].locality,
                addresses[0].subLocality,
                addresses[0].featureName
            )
            getCurrentData(lat.toString(), lng.toString())
            removeUpdate()
        }

    }

    fun getCurrentLocate(){
        Log.i("Locate", "Создаем манагера")
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 1f, locationListener)
    }

    private fun removeUpdate(){
        locationManager.removeUpdates(locationListener)
    }

    private inner class MyLocationListener : LocationListener{
        override fun onLocationChanged(location: Location?) {
            _latitude.value = location!!.latitude
            _longitude.value = location.longitude
            Log.i("Locate", "Получили локацию")
            reverseGeo(location.latitude, location.longitude)
        }

        override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {
            Log.i("Locate", "Изменение $p0")
        }

        override fun onProviderEnabled(p0: String?) {
            Log.i("Locate", "Включение $p0")
        }

        override fun onProviderDisabled(p0: String?) {
            Log.i("Locate", "Выключение $p0")
        }

    }

    internal fun getCurrentData(lat: String, lon: String) {
        val retrofit = Retrofit.Builder()
            .baseUrl(BaseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service = retrofit.create(WeatherService::class.java)
        val call = service.getCurrentWeatherData(lat, lon, AppId)
        call.enqueue(object : Callback<WeatherResponse> {
            override fun onResponse(call: Call<WeatherResponse>, response: Response<WeatherResponse>) {
                if (response.code() == 200) {
                    val weatherResponse = response.body()!!

                    val stringBuilder = "Country: " +
                            weatherResponse.sys!!.country +
                            "\n" +
                            "Temperature: " +
                            weatherResponse.main!!.temp +
                            "\n" +
                            "Temperature(Min): " +
                            weatherResponse.main!!.temp_min +
                            "\n" +
                            "Temperature(Max): " +
                            weatherResponse.main!!.temp_max +
                            "\n" +
                            "Humidity: " +
                            weatherResponse.main!!.humidity +
                            "\n" +
                            "Pressure: " +
                            weatherResponse.main!!.pressure

                    _weather.value = stringBuilder
                }
            }

            override fun onFailure(call: Call<WeatherResponse>, t: Throwable) {
                _weather.value = t.message
            }
        })
    }

    companion object {
        var BaseUrl = "http://api.openweathermap.org/"
        var AppId = "2e65127e909e178d0af311a81f39948c"
    }
}